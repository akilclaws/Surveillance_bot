from launch import LaunchDescription
from launch_ros.actions import Node

def generate_launch_description():
    return LaunchDescription([
        Node(
            package='go_home_service',
            executable='go_home_node',
            name='go_home_node',
            output='screen'
        )
    ])

