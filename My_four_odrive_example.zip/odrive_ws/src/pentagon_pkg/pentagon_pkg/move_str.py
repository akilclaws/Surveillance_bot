#!/usr/bin/env python3

import rclpy
from rclpy.node import Node
from nav_msgs.msg import Odometry
from geometry_msgs.msg import Twist
from math import sqrt, pow
import time # For initial delay

class GoStraightOdom(Node):
    def __init__(self):
        super().__init__('go_straight_odom')

        # Declare parameters with default values
        self.declare_parameter('target_distance', 1.0) # meters
        self.declare_parameter('kp_gain', 0.5)         # Proportional gain for velocity control
        self.declare_parameter('velocity_limit', 0.2)  # Max linear velocity (m/s)
        self.declare_parameter('stop_threshold', 0.02) # meters (how close to target to stop)
        self.declare_parameter('odom_topic', '/odom')
        self.declare_parameter('cmd_vel_topic', '/cmd_vel')

        # Get parameters
        self.target_distance = self.get_parameter('target_distance').get_parameter_value().double_value
        self.kp = self.get_parameter('kp_gain').get_parameter_value().double_value
        self.velocity_limit = self.get_parameter('velocity_limit').get_parameter_value().double_value
        self.stop_threshold = self.get_parameter('stop_threshold').get_parameter_value().double_value
        odom_topic = self.get_parameter('odom_topic').get_parameter_value().string_value
        cmd_vel_topic = self.get_parameter('cmd_vel_topic').get_parameter_value().string_value


        # Subscribers and Publishers
        self.odom_subscription = self.create_subscription(
            Odometry,
            odom_topic,
            self.odom_callback,
            10 # QoS: history depth
        )
        self.cmd_vel_publisher = self.create_publisher(Twist, cmd_vel_topic, 10)

        # State variables
        self.initial_x = None
        self.initial_y = None
        self.current_x = 0.0
        self.current_y = 0.0
        self.movement_started = False
        self.is_moving = False # Flag to indicate if the robot is currently being commanded to move

        self.get_logger().info(f"GoStraightOdom node initialized.")
        self.get_logger().info(f"Target distance: {self.target_distance:.2f}m")
        self.get_logger().info(f"Proportional gain (Kp): {self.kp}")
        self.get_logger().info(f"Velocity limit: {self.velocity_limit:.2f}m/s")
        self.get_logger().info(f"Stop threshold: {self.stop_threshold:.3f}m")
        self.get_logger().info(f"Subscribing to {odom_topic}")
        self.get_logger().info(f"Publishing to {cmd_vel_topic}")

        # Timer for control loop (controls how frequently we publish commands)
        self.timer = self.create_timer(0.1, self.control_loop) # 10 Hz control loop

    def odom_callback(self, msg):
        """
        Callback function for the /odom topic.
        Updates the robot's current position from odometry.
        """
        self.current_x = msg.pose.pose.position.x
        self.current_y = msg.pose.pose.position.y

        # If movement hasn't started, store the initial pose
        if not self.movement_started and self.initial_x is None:
            self.initial_x = self.current_x
            self.initial_y = self.current_y
            self.get_logger().info(f"Initial Odom Pose Recorded: X={self.initial_x:.3f}, Y={self.initial_y:.3f}")
            self.movement_started = True # Ensure initial pose is only set once per execution

    def control_loop(self):
        """
        This function is called periodically by the timer to control the robot's movement.
        """
        if not self.movement_started or self.initial_x is None:
            self.get_logger().info("Waiting for initial odometry data...")
            # Publish zero velocity while waiting to ensure robot is stopped
            self._stop_robot()
            return

        distance_traveled = sqrt(
            pow(self.current_x - self.initial_x, 2) +
            pow(self.current_y - self.initial_y, 2)
        )

        remaining_distance = self.target_distance - distance_traveled

        twist_msg = Twist()

        if remaining_distance <= self.stop_threshold:
            # Robot has reached or passed the target distance within the threshold
            if self.is_moving: # Only log once when stopping
                self.get_logger().info(f"Target reached! Distance traveled: {distance_traveled:.3f}m. Stopping robot.")
            self._stop_robot()
            # You might want to shut down the node here if it's a one-shot movement
            # rclpy.shutdown() 
            # Note: If you uncomment rclpy.shutdown(), the node will exit after moving 1m.
            # Otherwise, it will just stop and keep running, waiting for further commands/logic.
        else:
            # Calculate linear velocity using a P-controller
            linear_velocity = self.kp * remaining_distance

            # Apply velocity limit
            if linear_velocity > self.velocity_limit:
                linear_velocity = self.velocity_limit
            elif linear_velocity < -self.velocity_limit: # Should not happen for forward motion
                 linear_velocity = -self.velocity_limit
            
            # Ensure we move forward, even if remaining_distance is very small but positive
            if linear_velocity < 0.05 and remaining_distance > 0: # Minimum velocity to ensure movement
                 linear_velocity = 0.05 

            twist_msg.linear.x = linear_velocity
            twist_msg.angular.z = 0.0 # Ensure no angular movement

            self.cmd_vel_publisher.publish(twist_msg)
            self.is_moving = True
            self.get_logger().info(
                f"Moving... Dist Traveled: {distance_traveled:.3f}m, "
                f"Remaining: {remaining_distance:.3f}m, "
                f"Vel: {linear_velocity:.3f}m/s"
            )

    def _stop_robot(self):
        """Helper function to publish zero velocity and stop the robot."""
        stop_twist = Twist()
        stop_twist.linear.x = 0.0
        stop_twist.angular.z = 0.0
        self.cmd_vel_publisher.publish(stop_twist)
        self.is_moving = False


def main(args=None):
    rclpy.init(args=args)
    node = GoStraightOdom()
    rclpy.spin(node) # Keep the node alive and process callbacks
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()