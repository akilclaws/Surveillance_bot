#!/usr/bin/env python3

import rclpy
from rclpy.node import Node
from nav_msgs.msg import Odometry
from geometry_msgs.msg import Twist
from std_msgs.msg import Float32 # For angle input
from tf_transformations import euler_from_quaternion # For converting quaternion to Euler angles
from math import sqrt, pow, radians, degrees, atan2, sin, cos # Added sin, cos for atan2 normalization

class SequentialMoveNode(Node):
    # Define states for the state machine
    STATE_IDLE = 0
    STATE_TURNING = 1
    STATE_MOVING_FORWARD = 2

    def __init__(self):
        super().__init__('sequential_move_node')

        # --- Parameters ---
        self.declare_parameter('kp_angular', 0.8) # Proportional gain for angular velocity
        self.declare_parameter('kp_linear', 0.5)  # Proportional gain for linear velocity
        self.declare_parameter('angular_velocity_limit', 3.0) # rad/s
        self.declare_parameter('linear_velocity_limit', 0.2)  # m/s
        self.declare_parameter('angular_stop_threshold', 0.03) # radians (approx 1.7 degrees)
        self.declare_parameter('linear_stop_threshold', 0.02) # meters (2 cm)
        self.declare_parameter('forward_distance', 1.0) # meters
        self.declare_parameter('odom_topic', '/odom')
        self.declare_parameter('cmd_vel_topic', '/cmd_vel')
        self.declare_parameter('angle_input_topic', '/angle') # New parameter for angle topic name

        self.kp_angular = self.get_parameter('kp_angular').get_parameter_value().double_value
        self.kp_linear = self.get_parameter('kp_linear').get_parameter_value().double_value
        self.angular_velocity_limit = self.get_parameter('angular_velocity_limit').get_parameter_value().double_value
        self.linear_velocity_limit = self.get_parameter('linear_velocity_limit').get_parameter_value().double_value
        self.angular_stop_threshold = self.get_parameter('angular_stop_threshold').get_parameter_value().double_value
        self.linear_stop_threshold = self.get_parameter('linear_stop_threshold').get_parameter_value().double_value
        self.forward_distance = self.get_parameter('forward_distance').get_parameter_value().double_value
        odom_topic = self.get_parameter('odom_topic').get_parameter_value().string_value
        cmd_vel_topic = self.get_parameter('cmd_vel_topic').get_parameter_value().string_value
        angle_input_topic = self.get_parameter('angle_input_topic').get_parameter_value().string_value # Get angle topic

        # --- Subscriptions and Publishers ---
        self.odom_subscription = self.create_subscription(
            Odometry,
            odom_topic,
            self.odom_callback,
            10
        )
        self.angle_subscription = self.create_subscription(
            Float32,
            angle_input_topic, # Using the parameter for the topic name
            self.angle_callback,
            10
        )
        self.cmd_vel_publisher = self.create_publisher(Twist, cmd_vel_topic, 10)

        # --- State Variables ---
        self.current_state = self.STATE_IDLE
        self.current_x = 0.0
        self.current_y = 0.0
        self.current_yaw = 0.0

        # Turning specific variables
        self.initial_yaw = None
        self.target_yaw = None
        # self.angle_received = False # No longer needed, state machine handles this

        # Moving forward specific variables
        self.initial_forward_x = None
        self.initial_forward_y = None

        self.get_logger().info(f"SequentialMoveNode initialized. Waiting for angle commands on {angle_input_topic}")
        self.get_logger().info(f"Subscribing to {odom_topic}")
        self.get_logger().info(f"Publishing to {cmd_vel_topic}")
        self.get_logger().info(f"Forward distance: {self.forward_distance:.2f}m")

        # --- Control Loop Timer ---
        self.timer = self.create_timer(0.05, self.control_loop) # 20 Hz control loop

    def odom_callback(self, msg):
        """
        Updates robot's current position (x, y) and orientation (yaw) from odometry.
        """
        self.current_x = msg.pose.pose.position.x
        self.current_y = msg.pose.pose.position.y

        orientation_q = msg.pose.pose.orientation
        _, _, self.current_yaw = euler_from_quaternion([
            orientation_q.x, orientation_q.y, orientation_q.z, orientation_q.w
        ])

    def angle_callback(self, msg):
        """
        Receives target angle in degrees, converts to radians, and initiates turning.
        Only processes new commands if in IDLE state.
        """
        if self.current_state == self.STATE_IDLE:
            target_angle_deg = msg.data
            target_angle_rad = radians(target_angle_deg)

            self.initial_yaw = self.current_yaw # Record initial yaw for turning
            
            # Calculate target yaw relative to the current yaw
            self.target_yaw = self.initial_yaw + target_angle_rad

            # Normalize target_yaw to be within [-pi, pi] for easier comparison
            # This is crucial for smooth angle comparisons across the -pi/pi boundary
            self.target_yaw = atan2(sin(self.target_yaw), cos(self.target_yaw))

            self.get_logger().info(f"Received target angle: {target_angle_deg:.2f} deg ({target_angle_rad:.2f} rad)")
            self.get_logger().info(f"Initial Yaw: {self.initial_yaw:.2f} rad, Target Yaw: {self.target_yaw:.2f} rad")
            self.current_state = self.STATE_TURNING
            self.get_logger().info("Transitioning to STATE_TURNING.")
        else:
            self.get_logger().warn(f"Received angle command while in state {self.current_state}. Ignoring for now.")

    def control_loop(self):
        """
        Main control loop managing the state machine.
        """
        twist_msg = Twist()

        if self.current_state == self.STATE_IDLE:
            self._stop_robot()
            return # Do nothing until a new angle is received

        elif self.current_state == self.STATE_TURNING:
            if self.initial_yaw is None: # Wait for first odom data
                self.get_logger().warn("Waiting for initial yaw data for turning...")
                self._stop_robot()
                return

            # Calculate the shortest angle difference
            angle_error = self.target_yaw - self.current_yaw
            # Normalize error to be within [-pi, pi]
            angle_error = atan2(sin(angle_error), cos(angle_error))

            if abs(angle_error) < self.angular_stop_threshold:
                self.get_logger().info(f"Finished turning. Final Yaw: {self.current_yaw:.2f} rad. Error: {angle_error:.3f} rad")
                self._stop_robot()
                # Transition to moving forward
                self.initial_forward_x = self.current_x # Record initial pose for forward movement
                self.initial_forward_y = self.current_y
                self.current_state = self.STATE_MOVING_FORWARD
                self.get_logger().info("Transitioning to STATE_MOVING_FORWARD.")
            else:
                angular_velocity = self.kp_angular * angle_error
                # Clamp angular velocity
                if abs(angular_velocity) > self.angular_velocity_limit:
                    angular_velocity = self.angular_velocity_limit if angular_velocity > 0 else -self.angular_velocity_limit
                
                twist_msg.angular.z = angular_velocity
                self.cmd_vel_publisher.publish(twist_msg)
                # self.get_logger().info(f"Turning... Current Yaw: {self.current_yaw:.2f} rad, Error: {angle_error:.3f} rad, Angular Vel: {angular_velocity:.3f}")

        elif self.current_state == self.STATE_MOVING_FORWARD:
            if self.initial_forward_x is None: # Should not happen if transitions correctly
                 self.get_logger().warn("Waiting for initial forward pose data...")
                 self._stop_robot()
                 return

            distance_traveled = sqrt(
                pow(self.current_x - self.initial_forward_x, 2) +
                pow(self.current_y - self.initial_forward_y, 2)
            )
            remaining_distance = self.forward_distance - distance_traveled

            if remaining_distance <= self.linear_stop_threshold:
                self.get_logger().info(f"Finished moving forward. Distance traveled: {distance_traveled:.3f}m. Stopping robot.")
                self._stop_robot()
                self.current_state = self.STATE_IDLE # Back to idle, waiting for next command
                self.get_logger().info("Transitioning to STATE_IDLE. Waiting for next angle command.")
            else:
                linear_velocity = self.kp_linear * remaining_distance
                # Clamp linear velocity
                if linear_velocity > self.linear_velocity_limit:
                    linear_velocity = self.linear_velocity_limit
                elif linear_velocity < -self.linear_velocity_limit: # Should not happen
                    linear_velocity = -self.linear_velocity_limit
                
                # Ensure minimum forward velocity for friction
                if linear_velocity < 0.05 and remaining_distance > 0:
                    linear_velocity = 0.05

                twist_msg.linear.x = linear_velocity
                twist_msg.angular.z = 0.0 # Ensure no angular movement while moving straight
                self.cmd_vel_publisher.publish(twist_msg)
                # self.get_logger().info(f"Moving forward... Dist: {distance_traveled:.3f}m, Rem: {remaining_distance:.3f}m, Vel: {linear_velocity:.3f}")

    def _stop_robot(self):
        """Helper function to publish zero velocity and stop the robot."""
        stop_twist = Twist()
        stop_twist.linear.x = 0.0
        stop_twist.angular.z = 0.0
        self.cmd_vel_publisher.publish(stop_twist)


def main(args=None):
    rclpy.init(args=args)
    node = SequentialMoveNode()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
