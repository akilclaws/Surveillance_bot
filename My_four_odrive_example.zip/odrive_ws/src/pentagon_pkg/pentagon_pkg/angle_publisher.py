import rclpy
from rclpy.node import Node
from std_msgs.msg import Float32

class AnglePublisher(Node):
    """
    A ROS2 node that publishes a 72-degree angle to the 'angle' topic
    every 2 minutes, for a total of 7 times.
    """
    def __init__(self):
        # Initialize the ROS2 node with the name 'angle_publisher'
        super().__init__('angle_publisher')

        # Create a publisher for the 'angle' topic, using Float64 messages.
        # The queue size is set to 10, which is a common default.
        self.publisher_ = self.create_publisher(Float32, 'angle', 10)

        # Define the angle to be published (72 degrees)
        self.angle_to_publish = -72.0

        # Define the publishing interval in seconds (1 minutes = 60 seconds)
        self.publish_interval_sec = 30.0

        # Initialize a counter for the number of messages published
        self.message_count = 0

        # Set the maximum number of messages to publish
        self.max_messages = 5

        # Create a timer that calls the 'timer_callback' function
        # at the specified 'publish_interval_sec'
        self.timer = self.create_timer(self.publish_interval_sec, self.timer_callback)

        self.get_logger().info(f'Angle Publisher Node initialized. Publishing {self.angle_to_publish} degrees to /angle every {self.publish_interval_sec} seconds for {self.max_messages} times.')

    def timer_callback(self):
        """
        Callback function for the timer. This function is executed every
        'publish_interval_sec' seconds.
        """
        # Check if the maximum number of messages has been published
        if self.message_count >= self.max_messages:
            self.get_logger().info(f'Published {self.max_messages} messages. Shutting down publisher.')
            # Destroy the timer to stop further callbacks
            self.timer.destroy()
            # Destroy the node to clean up resources
            self.destroy_node()
            # Shut down rclpy to exit the program
            rclpy.shutdown()
            return

        # Create a new Float64 message
        msg = Float32()
        # Set the data of the message to the desired angle
        msg.data = self.angle_to_publish

        # Publish the message
        self.publisher_.publish(msg)

        # Increment the message count
        self.message_count += 1

        # Log a message to inform that the angle has been sent
        self.get_logger().info(f'Publishing: "{msg.data}" degrees. Message {self.message_count}/{self.max_messages}')

def main(args=None):
    """
    Main function to initialize and run the ROS2 node.
    """
    # Initialize the rclpy library
    rclpy.init(args=args)

    # Create an instance of the AnglePublisher node
    angle_publisher = AnglePublisher()

    try:
        # Spin the node to allow its callbacks (like the timer_callback)
        # to be executed. This keeps the node alive.
        rclpy.spin(angle_publisher)
    except KeyboardInterrupt:
        # Handle KeyboardInterrupt (Ctrl+C) for graceful shutdown
        angle_publisher.get_logger().info('Keyboard Interrupt detected. Shutting down...')
    finally:
        # Ensure the node is destroyed and rclpy is shut down
        # even if an exception occurs
        if rclpy.ok():
            angle_publisher.destroy_node()
            rclpy.shutdown()

if __name__ == '__main__':
    main()
