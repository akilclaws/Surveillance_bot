#!/usr/bin/env python3

import rclpy
from rclpy.node import Node
from sensor_msgs.msg import Image
from depthai_ros_msgs.msg import TrackDetection2DArray
from cv_bridge import CvBridge
import cv2
import numpy as np

class YOLOOverlayNode(Node):
    def __init__(self):
        super().__init__('yolo_overlay_node')
        self.bridge = CvBridge()
        self.latest_image = None
        self.track_colors = {}

        self.create_subscription(Image, '/color/image', self.image_callback, 10)
        self.create_subscription(TrackDetection2DArray, '/color/yolov4_tracklets', self.track_callback, 10)
        self.publisher = self.create_publisher(Image, '/color/image_annotated', 10)

    def image_callback(self, msg):
        self.latest_image = msg

    def get_color_for_track(self, track_id):
        # Deterministic vivid colors
        np.random.seed(int(track_id) if track_id.isdigit() else hash(track_id) % 1000)
        return tuple(int(c) for c in np.random.choice(range(80, 256), size=3))

    def track_callback(self, msg):
        if self.latest_image is None:
            return

        cv_img = self.bridge.imgmsg_to_cv2(self.latest_image, desired_encoding='bgr8')
        height, width, _ = cv_img.shape

        detections = msg.detections
        if not detections:
            self.get_logger().info("No detections.")
        else:
            self.get_logger().info(f"Received {len(detections)} detections.")

        for det in detections:
            try:
                cx = int(det.bbox.center.position.x * width)
                cy = int(det.bbox.center.position.y * height)
                bw = int(det.bbox.size_x)
                bh = int(det.bbox.size_y)

                x1 = max(cx - bw // 2, 0)
                y1 = max(cy - bh // 2, 0)
                x2 = min(cx + bw // 2, width - 1)
                y2 = min(cy + bh // 2, height - 1)

                color = self.get_color_for_track(det.tracking_id)

                # Draw thick, bright box
                cv2.rectangle(cv_img, (x1, y1), (x2, y2), color, 3)

                # Draw tracking ID
                label = f"ID: {det.tracking_id}"
                cv2.putText(cv_img, label, (x1, max(0, y1 - 10)),
                            cv2.FONT_HERSHEY_SIMPLEX, 0.7, color, 2)
                
                self.get_logger().info(f'Drew box for {label}: ({x1},{y1}) to ({x2},{y2})')

            except Exception as e:
                self.get_logger().error(f"Error drawing bbox: {e}")

        annotated = self.bridge.cv2_to_imgmsg(cv_img, encoding='bgr8')
        annotated.header = self.latest_image.header
        self.publisher.publish(annotated)

def main(args=None):
    rclpy.init(args=args)
    node = YOLOOverlayNode()
    rclpy.spin(node)
    rclpy.shutdown()

if __name__ == '__main__':
    main()

