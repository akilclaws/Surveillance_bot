# rgbd_odometry.launch.py
#
# Run rtabmap_odom::RGBDOdometry as a stand-alone node.
# -------------------------------------------------------------------
import launch
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node


def generate_launch_description():
    # ── CLI arguments ────────────────────────────────────────────────
    declare_name       = DeclareLaunchArgument('name',         default_value='oak')
    declare_frame_id   = DeclareLaunchArgument('frame_id',     default_value='base_link')
    declare_odom_topic = DeclareLaunchArgument('odom_topic',   default_value='odom_2')
    declare_rgb_topic  = DeclareLaunchArgument('rgb_topic',    default_value='/oak/rgb/image_raw')
    declare_depth_topic= DeclareLaunchArgument('depth_topic',  default_value='/oak/stereo/image_raw')
    declare_info_topic = DeclareLaunchArgument('info_topic',   default_value='/oak/rgb/camera_info')
    declare_prefix     = DeclareLaunchArgument('launch_prefix',default_value='')   # e.g. "stdbuf -oL"

    # ── Odometry node ────────────────────────────────────────────────
    odom_node = Node(
        package   = 'rtabmap_odom',
        executable= 'rgbd_odometry',
        name      = 'rgbd_odometry',
        output    = 'screen',
        emulate_tty = True,
        prefix    = LaunchConfiguration('launch_prefix'),
        parameters=[{
            'frame_id':      LaunchConfiguration('frame_id'),
            'odom_frame_id': '',              # child of map / parent of base_link
            'publish_tf':    True,
            'approx_sync':   True,                # good default for USB cameras
            'subscribe_rgbd': False               # we feed raw RGB + depth
        }],
        remappings=[
            ('rgb/image',       LaunchConfiguration('rgb_topic')),
            ('depth/image',     LaunchConfiguration('depth_topic')),
            ('rgb/camera_info', LaunchConfiguration('info_topic')),
            ('odom',            LaunchConfiguration('odom_topic')),
        ],
    )

    # ── Launch description ───────────────────────────────────────────
    return LaunchDescription([
        declare_name, declare_frame_id, declare_odom_topic,
        declare_rgb_topic, declare_depth_topic, declare_info_topic,
        declare_prefix,
        odom_node,
    ])

