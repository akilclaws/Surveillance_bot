#!/usr/bin/env python3
import os

from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, IncludeLaunchDescription
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import LaunchConfiguration
from ament_index_python.packages import get_package_share_directory


def generate_launch_description():
    # --- CLI args -------------------------------------------------------------
    localization_arg = DeclareLaunchArgument(
        "localization", default_value="false",
        description="Enable localization mode (no mapping, use existing map)",
    )

    # --- Upstream RTAB‑Map launch --------------------------------------------
    pkg_share = get_package_share_directory("odrive_botwheel_explorer")
    base_launch = os.path.join(pkg_share, "launch", "rtabmap.launch.py")

    rtabmap_launch = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(base_launch),
        launch_arguments={
            # Disable odom inside RTAB‑Map – we will run it separately
            "visual_odometry": "false",
            "icp_odometry":    "false",

            # Pass‑through localization flag
            "localization": LaunchConfiguration("localization"),

            # Frame settings ---------------------------------------------------
            "frame_id":       "base_link",
            "map_frame_id":   "map",   
            "odom_frame_id":  "",          # Listen to external odom on /odom topic if empty
            "use_sim_time":   "false",
	    "Rtabmap/DetectionRate":  "1",
	    "publish_tf":     "false",
            # RGB stream (raw bgr8) -------------------------------------------
            "rgb_topic":           "/oak/rgb/image_raw",
            "rgb_image_transport": "raw",
            "camera_info_topic":   "/oak/rgb/camera_info",
            "subscribe_rgb":       "true",
            

            # Depth stream (raw 16UC1) ----------------------------------------
            "depth_topic":           "/oak/stereo/image_raw",
            "depth_image_transport": "raw",
            "subscribe_depth":       "true",
            "subscribe_cloud": "true",
            "subscribe_odom": "true",
            "cloud_topic":     "/oak/points",
            "odom_topic": "/odom",
            "depth_scale":           "1.0",

            # Point Cloud Data -------------------------------------------------
            "subscribe_rgbd":      "true",  # Enable RGB-D subscription for point cloud
            "approx_sync":         "true",  # Use approximate synchronization for RGB-D
            "publish_pointcloud":  "true",  # Enable publishing of the point cloud
            "point_cloud_topic":   "/rtabmap/cloud_map", # Default point cloud topic

            # Synchronization --------------------------------------------------
            "rgbd_sync":        "true",
            "approx_rgbd_sync": "true",
            "topic_queue_size": "10",
            "sync_queue_size":  "10",

            # QoS --------------------------------------------------------------
            "qos":            "0",  # system default
            "qos_image":      "2",  # Best Effort for images
            "qos_camera_info": "1",  # Reliable for camera_info
            "qos_imu":         "1",  # Reliable for IMU
            "qos_scan":            "2",
            "qos_odom": "2",

            # IMU --------------------------------------------------------------
            "subscribe_imu":   "false",

            # Disable unused sensors ------------------------------------------
            "subscribe_scan":        "false",
            "subscribe_scan_cloud":  "false",
            "subscribe_user_data":   "false",

            # Visualization ----------------------------------------------------
            "rtabmap_viz": "true",
            "rviz":        "true",
        }.items(),
    )

    return LaunchDescription([
        localization_arg,
        rtabmap_launch,
    ])
