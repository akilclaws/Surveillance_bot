import os
from ament_index_python.packages import get_package_share_directory
 
from launch import LaunchDescription
from launch.actions import IncludeLaunchDescription
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch_ros.actions import Node, ComposableNodeContainer
from launch_ros.descriptions import ComposableNode
 
def generate_launch_description():
    # Shared parameters
    parameters=[{
        'frame_id': 'base_link',
        'subscribe_rgbd': True,
        'subscribe_odom_info': True,
        'approx_sync': False,
        'wait_imu_to_init': True
    }]
 
    remappings=[('imu', '/imu/data')]
 
    # Depth and grayscale-based point cloud generation (depth_aligned = false)
    depth_metric_converter = ComposableNode(
        package='depth_image_proc',
        plugin='depth_image_proc::ConvertMetricNode',
        name='convert_metric_node',
        remappings=[
            ('image_raw', '/stereo/depth'),
            ('camera_info', '/stereo/camera_info'),
            ('image', '/stereo/converted_depth')
        ]
    )
 
    point_cloud_creator = ComposableNode(
        package='depth_image_proc',
        plugin='depth_image_proc::PointCloudXyziNode',
        name='point_cloud_xyzi_node',
        remappings=[
            ('depth/image_rect', '/stereo/converted_depth'),
            ('intensity/image_rect', '/right/image_rect'),
            ('intensity/camera_info', '/right/camera_info'),
            ('points', '/oak/points')
        ]
    )
 
    point_cloud_container = ComposableNodeContainer(
        name='point_cloud_container',
        namespace='',
        package='rclcpp_components',
        executable='component_container_mt',
        composable_node_descriptions=[
            depth_metric_converter,
            point_cloud_creator
        ],
        output='screen'
    )
 
    return LaunchDescription([
        # Launch the OAK-D stereo inertial node
        IncludeLaunchDescription(
            PythonLaunchDescriptionSource([
                os.path.join(
                    get_package_share_directory('odrive_botwheel_explorer'),
                    'launch',
                    'stereo_inertial_node.launch.py'
                )
            ]),
            launch_arguments={
                'depth_aligned': 'false',
                'enableRviz': 'false',
                'monoResolution': '400p'
            }.items()
        ),
 
        # Synchronize RGB-D (right mono + depth)
        Node(
            package='rtabmap_sync',
            executable='rgbd_sync',
            output='screen',
            parameters=parameters,
            remappings=[
                ('rgb/image', '/right/image_rect'),
                ('rgb/camera_info', '/right/camera_info'),
                ('depth/image', '/stereo/depth')
            ]
        ),
 
        # Filter IMU data (quaternion output)
        Node(
            package='imu_filter_madgwick',
            executable='imu_filter_madgwick_node',
            output='screen',
            parameters=[{
                'use_mag': False,
                'world_frame': 'enu',
                'publish_tf': False
            }],
            remappings=[('imu/data_raw', '/imu')]
        ),
 
        # Visual odometry
        Node(
            package='rtabmap_odom',
            executable='rgbd_odometry',
            output='screen',
            parameters=parameters,
            remappings=remappings
        ),
 
        # RTAB-Map SLAM node
        Node(
            package='rtabmap_slam',
            executable='rtabmap',
            output='screen',
            parameters=parameters,
            remappings=remappings,
            arguments=['-d']
        ),
 
        # RTAB-Map Visualizer
        Node(
            package='rtabmap_viz',
            executable='rtabmap_viz',
            output='screen',
            parameters=parameters,
            remappings=remappings
        ),
 
        # Point cloud node container
        point_cloud_container
    ])
