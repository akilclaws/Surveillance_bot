# Copyright 2020 ros2_control Development Team
# Licensed under the Apache License, Version 2.0 (see LICENSE)

from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, RegisterEventHandler
from launch.conditions import IfCondition
from launch.event_handlers import OnProcessExit
from launch.substitutions import Command, FindExecutable, PathJoinSubstitution, LaunchConfiguration

from launch_ros.actions import Node
from launch_ros.substitutions import FindPackageShare


def generate_launch_description():
    # ─────────────── launch-time arguments ───────────────
    declared_arguments = [
        DeclareLaunchArgument(
            "gui",
            default_value="true",
            description="Start RViz2 automatically with this launch file.",
        ),
        # If you need mock hardware, uncomment the block below and the
        # corresponding xacro arguments; left out here for clarity.
        # DeclareLaunchArgument(
        #     "use_mock_hardware",
        #     default_value="false",
        #     description="Start robot with mock hardware mirroring command to its states.",
        # ),
    ]

    gui = LaunchConfiguration("gui")
    # use_mock_hardware = LaunchConfiguration("use_mock_hardware")

    # ─────────────── robot description from xacro ───────────────
    robot_description_content = Command(
        [
            PathJoinSubstitution([FindExecutable(name="xacro")]),
            " ",
            PathJoinSubstitution(
                [FindPackageShare("odrive_botwheel_explorer"), "urdf", "diffbot.urdf.xacro"]
            ),
            # " ",
            # "use_mock_hardware:=", use_mock_hardware,
        ]
    )
    robot_description = {"robot_description": robot_description_content}

    # ─────────────── controller & RViz configs ───────────────
    robot_controllers = PathJoinSubstitution(
        [FindPackageShare("odrive_botwheel_explorer"), "config", "diff_with_pid.yaml"]
    )
    rviz_config_file = PathJoinSubstitution(
        [FindPackageShare("ros2_control_demo_description"), "diffbot/rviz", "diffbot.rviz"]
    )

    # ─────────────── core ros2_control node ───────────────
    control_node = Node(
        package="controller_manager",
        executable="ros2_control_node",
        parameters=[robot_description, robot_controllers],
        remappings=[
            ("/botwheel_explorer/cmd_vel_unstamped", "/cmd_vel"),
            ("/botwheel_explorer/odom", "/odom"),
        ],
        output="both",
    )

    robot_state_pub_node = Node(
        package="robot_state_publisher",
        executable="robot_state_publisher",
        output="both",
        parameters=[robot_description],
    )

    rviz_node = Node(
        package="rviz2",
        executable="rviz2",
        name="rviz2",
        output="log",
        arguments=["-d", rviz_config_file],
        condition=IfCondition(gui),
    )

    # ─────────────── controller spawners ───────────────
    joint_state_broadcaster_spawner = Node(
        package="controller_manager",
        executable="spawner",
        arguments=["joint_state_broadcaster", "--controller-manager", "/controller_manager"],
    )

    # Per-wheel velocity controllers (must match names in diff_with_pid.yaml)
    front_left_wheel_spawner = Node(
        package="controller_manager",
        executable="spawner",
        arguments=["front_left_wheel_vel_ctrl", "--controller-manager", "/controller_manager"],
    )
    rear_left_wheel_spawner = Node(
        package="controller_manager",
        executable="spawner",
        arguments=["rear_left_wheel_vel_ctrl", "--controller-manager", "/controller_manager"],
    )
    front_right_wheel_spawner = Node(
        package="controller_manager",
        executable="spawner",
        arguments=["front_right_wheel_vel_ctrl", "--controller-manager", "/controller_manager"],
    )
    rear_right_wheel_spawner = Node(
        package="controller_manager",
        executable="spawner",
        arguments=["rear_right_wheel_vel_ctrl", "--controller-manager", "/controller_manager"],
    )

    # Diff-drive controller (depends on wheel controllers)
    botwheel_explorer_spawner = Node(
        package="controller_manager",
        executable="spawner",
        arguments=["botwheel_explorer", "--controller-manager", "/controller_manager"],
    )

    # ─────────────── launch order orchestration ───────────────
    # 1. joint_state_broadcaster → 2. all wheel controllers → 3. diff-drive
    delay_all_controllers_after_jsb = RegisterEventHandler(
        event_handler=OnProcessExit(
            target_action=joint_state_broadcaster_spawner,
            on_exit=[
                front_left_wheel_spawner,
                rear_left_wheel_spawner,
                front_right_wheel_spawner,
                rear_right_wheel_spawner,
                botwheel_explorer_spawner,
            ],
        )
    )
    # RViz can also wait for joint_state_broadcaster if desired
    delay_rviz_after_jsb = RegisterEventHandler(
        event_handler=OnProcessExit(
            target_action=joint_state_broadcaster_spawner,
            on_exit=[rviz_node],
        )
    )

    # ─────────────── assemble launch description ───────────────
    nodes = [
        control_node,
        robot_state_pub_node,
        joint_state_broadcaster_spawner,
        delay_all_controllers_after_jsb,
        #delay_rviz_after_jsb,
    ]

    return LaunchDescription(declared_arguments + nodes)

