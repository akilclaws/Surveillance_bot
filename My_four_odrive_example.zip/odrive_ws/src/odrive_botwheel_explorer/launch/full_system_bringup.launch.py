import os
from launch import LaunchDescription
from launch.actions import IncludeLaunchDescription
from launch.launch_description_sources import PythonLaunchDescriptionSource
from ament_index_python.packages import get_package_share_directory

def include(pkg_share_dir, file_name, **kwargs):
    """Utility to create an IncludeLaunchDescription for <pkg>/launch/<file_name>."""
    return IncludeLaunchDescription(
        PythonLaunchDescriptionSource(
            os.path.join(pkg_share_dir, 'launch', file_name)
        ),
        **kwargs  # e.g. launch_arguments={'use_sim_time': 'true'}.items()
    )

def generate_launch_description():
    pkg_name = 'odrive_botwheel_explorer'
    share_dir = get_package_share_directory(pkg_name)

    return LaunchDescription([
        include(share_dir, 'botwheel_explorer.launch.py'),
        include(share_dir, 'camera_as_part_of_a_robot.launch.py'),
        include(share_dir, 'test.launch.py'),
        include(share_dir, 'ekf.launch.py'),
    ])

