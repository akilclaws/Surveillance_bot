#!/usr/bin/env python3
import os

from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, IncludeLaunchDescription
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import LaunchConfiguration
from ament_index_python.packages import get_package_share_directory


def generate_launch_description():
    # --- CLI args -------------------------------------------------------------
    localization_arg = DeclareLaunchArgument(
        "localization", default_value="false",
        description="Enable localization mode (no mapping, use existing map)",
    )

    # existing grid/noise params...
    grid_cell_size_arg = DeclareLaunchArgument(
        "grid_cell_size", default_value="0.05",
        description="Cell size (in meters) for the occupancy grid",
    )
    noise_filter_radius_arg = DeclareLaunchArgument(
        "noise_filter_radius", default_value="0.02",
        description="Radius (in meters) for removing isolated points in the cloud",
    )
    noise_filter_neighbors_arg = DeclareLaunchArgument(
        "noise_filter_neighbors", default_value="5",
        description="Minimum neighbors within radius to keep a point",
    )

    # --- New RTAB-Map tuning params ------------------------------------------
    neighbor_refine_arg = DeclareLaunchArgument(
        "neighbor_refining", default_value="true",
        description="Enable neighbouring link refining",
    )
    angular_update_arg = DeclareLaunchArgument(
        "angular_update", default_value="0.1",
        description="Angular update threshold (radians) for keyframe creation",
    )
    linear_update_arg = DeclareLaunchArgument(
        "linear_update", default_value="0.2",
        description="Linear update threshold (meters) for keyframe creation",
    )
    optimizer_end_arg = DeclareLaunchArgument(
        "optimizer_from_graph_end", default_value="true",
        description="Run graph optimizer from the last node (graph end)",
    )
    use_3dof_arg = DeclareLaunchArgument(
        "use_3dof", default_value="false",
        description="Restrict pose estimation to 3 DoF (planar)",
    )
    min_inliers_arg = DeclareLaunchArgument(
        "min_inliers", default_value="20",
        description="Minimum inliers for ICP/RANSAC to accept a link",
    )
    linear_distance_arg = DeclareLaunchArgument(
        "linear_distance", default_value="0.5",
        description="Maximum linear distance (meters) for scan matching",
    )
    time_threshold_arg = DeclareLaunchArgument(
        "time_threshold", default_value="0.5",
        description="Time threshold (seconds) between keyframes",
    )
    rehearsal_sim_arg = DeclareLaunchArgument(
        "rehearsal_similarity", default_value="0.9",
        description="Similarity threshold for loop closure rehearsal",
    )
    memory_increment_arg = DeclareLaunchArgument(
        "memory_increment", default_value="100",
        description="Increment size for memory buffer (number of images)",
    )

    # --- Upstream RTAB-Map launch --------------------------------------------
    pkg_share = get_package_share_directory("odrive_botwheel_explorer")
    base_launch = os.path.join(pkg_share, "launch", "rtabmap.launch.py")

    rtabmap_launch = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(base_launch),
        launch_arguments={

            # Disable odom inside RTAB-Map – we will run it separately
            "visual_odometry": "false",
            "icp_odometry":    "false",

            # Pass-through localization flag
            "localization": LaunchConfiguration("localization"),

            # Frame settings ---------------------------------------------------
            "frame_id":       "base_link",
            "map_frame_id":   "map",
            "odom_frame_id":  "",
            "use_sim_time":   "false",
            "Rtabmap/DetectionRate":  "10",
            "publish_tf":     "true",

            # --- GRID SIZE --------------------------------------------------
            "Grid/CellSize": LaunchConfiguration("grid_cell_size"),

            # --- NOISE FILTERING --------------------------------------------
            "Filtering/Radius":              LaunchConfiguration("noise_filter_radius"),
            "Filtering/RadiusMinNeighbors": LaunchConfiguration("noise_filter_neighbors"),

            # --- KEYFRAME UPDATE THRESHOLDS ---------------------------------
            "Reg/AngularUpdate": LaunchConfiguration("angular_update"),
            "Reg/LinearUpdate":  LaunchConfiguration("linear_update"),

            # --- NEIGHBOUR LINK & OPTIMIZER ---------------------------------
            "RGBD/NeighborLinkRefining":     LaunchConfiguration("neighbor_refining"),
            "Mem/Increment":                 LaunchConfiguration("memory_increment"),
            "Optimizer/FromGraphEnd":        LaunchConfiguration("optimizer_from_graph_end"),

            # --- POSE DIMENSIONALITY & FILTERS -----------------------------
            "Odom/MaxLinear":      LaunchConfiguration("linear_distance"),
            "Odom/MaxAngular":     "1.57",  # leave default or expose as arg if desired
            "Odom/MinInliers":     LaunchConfiguration("min_inliers"),
            "Odom/TimeThreshold":  LaunchConfiguration("time_threshold"),
            "Odom/Use3DoF":        LaunchConfiguration("use_3dof"),

            # --- LOOP REHEARSAL & SIMILARITY -------------------------------
            "Loop/RehearsalSimilarity": LaunchConfiguration("rehearsal_similarity"),

            # RGB stream ----------------------------------------------------
            "rgb_topic":           "/oak/rgb/image_raw",
            "rgb_image_transport": "raw",
            "camera_info_topic":   "/oak/rgb/camera_info",
            "subscribe_rgb":       "true",

            # Depth stream --------------------------------------------------
            "depth_topic":           "/oak/stereo/image_raw",
            "depth_image_transport": "raw",
            "subscribe_depth":       "true",
            "subscribe_cloud":       "true",
            "subscribe_odom":        "true",
            "cloud_topic":          "/oak/points",
            "odom_topic":           "/odom",
            "depth_scale":           "1.0",

            # Point Cloud Data ---------------------------------------------
            "subscribe_rgbd":      "true",
            "approx_sync":         "true",
            "publish_pointcloud":  "true",
            "point_cloud_topic":   "/rtabmap/cloud_map",

            # Synchronization -----------------------------------------------
            "rgbd_sync":        "true",
            "approx_rgbd_sync": "true",
            "topic_queue_size": "10",
            "sync_queue_size":  "10",

            # QoS ------------------------------------------------------------
            "qos":            "0",
            "qos_image":      "2",
            "qos_camera_info": "1",
            "qos_imu":         "1",
            "qos_scan":        "2",
            "qos_odom":        "2",

            # IMU ------------------------------------------------------------
            "imu_topic": "/oak/imu/data",

            # Disable unused sensors ----------------------------------------
            "subscribe_scan":        "false",
            "subscribe_scan_cloud":  "false",
            "subscribe_user_data":   "false",

            # Visualization -------------------------------------------------
            "rtabmap_viz": "true",
            "rviz":        "true",
        }.items(),
    )

    return LaunchDescription([
        localization_arg,
        grid_cell_size_arg,
        noise_filter_radius_arg,
        noise_filter_neighbors_arg,
        neighbor_refine_arg,
        angular_update_arg,
        linear_update_arg,
        optimizer_end_arg,
        use_3dof_arg,
        min_inliers_arg,
        linear_distance_arg,
        time_threshold_arg,
        rehearsal_sim_arg,
        memory_increment_arg,
        rtabmap_launch,
    ])

