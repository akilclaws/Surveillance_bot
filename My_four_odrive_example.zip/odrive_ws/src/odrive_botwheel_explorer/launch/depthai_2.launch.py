import os

from ament_index_python.packages import get_package_share_directory

from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, IncludeLaunchDescription
from launch.conditions import IfCondition, UnlessCondition
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node, ComposableNodeContainer
from launch_ros.descriptions import ComposableNode


def generate_launch_description():
    # Launch arguments
    localization_arg = DeclareLaunchArgument(
        'localization', default_value='false'
    )
    map_arg = DeclareLaunchArgument(
        'map', default_value='/home/ubuntu/.ros/rtabmap_1.db'
    )

    localization = LaunchConfiguration('localization')
    map_db = LaunchConfiguration('map')

    # Common parameters (used for both modes)
    common_parameters = [{
        'frame_id': 'base_link',
        'subscribe_rgbd': True,
        'subscribe_odom_info': True,
        'approx_sync': False,
        'wait_imu_to_init': True,
        'publish_tf': True  # Ensures TF is published by RTAB-Map
    }]

    # Localization-specific parameters
    localization_params = [
        {'Mem/IncrementalMemory': 'false'},
        {'Mem/InitWMWithAllNodes': 'true'},
        {'RGBD/LocalLoopDetection': 'false'},
        {'grid/FromDepth': 'true'},
        {'rtabmap/DetectionRate': 1.0}
    ]

    remappings = [('imu', '/imu/data')]

    # Convert depth to metric
    depth_metric_converter = ComposableNode(
        package='depth_image_proc',
        plugin='depth_image_proc::ConvertMetricNode',
        name='convert_metric_node',
        remappings=[
            ('image_raw', '/stereo/depth'),
            ('camera_info', '/stereo/camera_info'),
            ('image', '/stereo/converted_depth')
        ]
    )

    # Create point cloud
    point_cloud_creator = ComposableNode(
        package='depth_image_proc',
        plugin='depth_image_proc::PointCloudXyziNode',
        name='point_cloud_xyzi_node',
        remappings=[
            ('depth/image_rect', '/stereo/converted_depth'),
            ('intensity/image_rect', '/right/image_rect'),
            ('intensity/camera_info', '/right/camera_info'),
            ('points', '/oak/points')
        ]
    )

    point_cloud_container = ComposableNodeContainer(
        name='point_cloud_container',
        namespace='',
        package='rclcpp_components',
        executable='component_container_mt',
        composable_node_descriptions=[
            depth_metric_converter,
            point_cloud_creator
        ],
        output='screen'
    )

    return LaunchDescription([
        localization_arg,
        map_arg,

        # Launch the OAK-D camera node
        IncludeLaunchDescription(
            PythonLaunchDescriptionSource([
                os.path.join(
                    get_package_share_directory('odrive_botwheel_explorer'),
                    'launch',
                    'stereo_inertial_node.launch.py'
                )
            ]),
            launch_arguments={
                'depth_aligned': 'false',
                'enableRviz': 'false',
                'monoResolution': '400p'
            }.items(),
        ),

        # Synchronize RGB-D data (only in mapping mode)
        Node(
            package='rtabmap_sync',
            executable='rgbd_sync',
            output='screen',
            parameters=common_parameters,
            remappings=[
                ('rgb/image', '/right/image_rect'),
                ('rgb/camera_info', '/right/camera_info'),
                ('depth/image', '/stereo/depth')
            ],
        ),

        # IMU filtering
        Node(
            package='imu_filter_madgwick',
            executable='imu_filter_madgwick_node',
            name= 'imu_filter_madgwick_node',
            output='screen',
            parameters=[
                {'use_mag': False},
                {'world_frame': 'enu'},
                {'publish_tf': False}
            ],
            remappings=[('imu/data_raw', '/imu')]
        ),

        # RGBD odometry (always running)
        Node(
            package='rtabmap_odom',
            executable='rgbd_odometry',
            output='screen',
            parameters=common_parameters,
            remappings=remappings
        ),

        # RTAB-Map for mapping
        Node(
            package='rtabmap_slam',
            executable='rtabmap',
            output='screen',
            parameters=common_parameters,
            remappings=remappings,
            arguments=['-d'],
            condition=UnlessCondition(localization)
        ),

        # RTAB-Map for localization
        Node(
            package='rtabmap_slam',
            executable='rtabmap',
            output='screen',
            parameters=common_parameters + localization_params,
            remappings=remappings,
            arguments=['--database', map_db, '-d'],
            condition=IfCondition(localization)
        ),

        # RTAB-Map Visualizer (always running)
        Node(
            package='rtabmap_viz',
            executable='rtabmap_viz',
            output='screen',
            parameters=common_parameters,
            remappings=remappings
        ),

        # Point cloud conversion nodes
        point_cloud_container
    ])

