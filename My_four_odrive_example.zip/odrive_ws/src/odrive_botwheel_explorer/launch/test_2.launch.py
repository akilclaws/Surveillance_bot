#!/usr/bin/env python3
import os

from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, IncludeLaunchDescription
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import LaunchConfiguration
from ament_index_python.packages import get_package_share_directory

def generate_launch_description():
    # --- CLI args -------------------------------------------------------------
    localization_arg = DeclareLaunchArgument(
        "localization", default_value="false",
        description="Enable localization mode (no mapping, use existing map)",
    )

    # --- Upstream RTAB​‑Map launch --------------------------------------------
    pkg_share = get_package_share_directory("odrive_botwheel_explorer")
    base_launch = os.path.join(pkg_share, "launch", "rtabmap.launch.py")

    rtabmap_launch = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(base_launch),
        launch_arguments={
            # Disable odom inside RTAB​‑Map – we will run it separately
            "visual_odometry": "true",
            "icp_odometry":    "false",

            # Pass​‑through localization flag
            "localization": LaunchConfiguration("localization"),

            # Frame settings ---------------------------------------------------
            "frame_id":       "base_link",
            "map_frame_id":   "map",
            "odom_frame_id":  "",
            "use_sim_time":   "false",
            "Rtabmap/DetectionRate":  "10",
            "publish_tf":     "true",

            # RGB stream (raw bgr8) -------------------------------------------
            "rgb_topic":           "/camera/camera/color/image_raw",
            "rgb_image_transport": "raw",
            "camera_info_topic":   "/camera/camera/color/camera_info",
            "subscribe_rgb":       "true",

            # Depth stream (raw 16UC1) ----------------------------------------
            "depth_topic":           "/camera/camera/depth/image_rect_raw",
            "depth_image_transport": "raw",
            "subscribe_depth":       "true",

            # IR streams -------------------------------------------------------
            "subscribe_stereo":      "true",
            "left_image_topic":      "/camera/camera/infra1/image_rect_raw",
            "right_image_topic":     "/camera/camera/infra2/image_rect_raw",
            "left_camera_info_topic":  "/camera/camera/infra1/camera_info",
            "right_camera_info_topic": "/camera/camera/infra2/camera_info",

            # Point Cloud Data -------------------------------------------------
            "subscribe_cloud": "true",
            "cloud_topic":     "/camera/camera/depth/color/points",

            # Use RGBD or stereo input
            "subscribe_rgbd":      "false",
            "subscribe_depth":     "true",
            "approx_sync":         "true",
            "publish_pointcloud":  "true",
            "point_cloud_topic":   "/rtabmap/cloud_map",

            # Synchronization --------------------------------------------------
            "rgbd_sync":        "true",
            "approx_rgbd_sync": "true",
            "topic_queue_size": "10",
            "sync_queue_size":  "10",

            # QoS --------------------------------------------------------------
            "qos":            "0",
            "qos_image":      "2",
            "qos_camera_info": "1",
            "qos_imu":         "1",
            "qos_scan":        "2",
            "qos_odom":        "2",

            # IMU --------------------------------------------------------------
            "imu_topic": "/oak/imu/data",

            # Disable unused sensors ------------------------------------------
            "subscribe_scan":        "false",
            "subscribe_scan_cloud":  "false",
            "subscribe_user_data":   "false",

            # Visualization ----------------------------------------------------
            "rtabmap_viz": "true",
            "rviz":        "true",
        }.items(),
    )

    return LaunchDescription([
        localization_arg,
        rtabmap_launch,
    ])

