import os
from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch_ros.actions import Node

def generate_launch_description():
    # --- Configuration ---
    # IMPORTANT: Replace 'YOUR_PACKAGE_NAME' with the actual name of your ROS 2 package.
    package_name = 'odrive_botwheel_explorer' 
    
    # Get the path to your package's share directory
    share_dir = get_package_share_directory(package_name)
    
    # Define the path to your EKF configuration file
    # If you want to hard-code the absolute path
    ekf_config_path = '/home/ubuntu/odrive_ws/src/odrive_botwheel_explorer/config/ekf_sensor_f.yaml'


    # --- Nodes to Launch ---
    # robot_localization EKF node
    ekf_node = Node(
    package='robot_localization',
    executable='ekf_node',        # <-- ROS 2 name
    name='ekf_filter_node',       # whatever you want to call the node
    parameters=[ekf_config_path], # points to /home/ubuntu/odrive_ws/src/odrive_botwheel_explorer/config/ekf_sensor_f.yaml
    remappings=[
    	('/odometry/filtered','/odom')
    ],
    output='screen'
    )
    # --- Launch Description ---
    # Create the LaunchDescription object and add the EKF node to it
    return LaunchDescription([
        ekf_node
    ])
