from launch import LaunchDescription
from launch.actions import IncludeLaunchDescription, GroupAction
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch_ros.actions import SetRemap
import os
from ament_index_python.packages import get_package_share_directory

def generate_launch_description():
    # Get the share directory for the 'odrive_botwheel_explorer' package
    odrive_botwheel_explorer_share_dir = get_package_share_directory('odrive_botwheel_explorer')

    # Path to the original launch file
    original_launch_file = os.path.join(
        odrive_botwheel_explorer_share_dir,
        'launch',
        'camera.launch.py'
    )

    return LaunchDescription([
        # Use GroupAction to apply remapping to all actions within this group,
        # including those from the included launch file.
        GroupAction(
            actions=[
                # SetRemap applies the remapping rule.
                # It takes 'src' (original topic) and 'dst' (new topic).
                SetRemap(src='/oak/rgb/image_raw', dst='/camera/image_raw'),

                # Include the original launch file within this group.
                IncludeLaunchDescription(
                    PythonLaunchDescriptionSource(original_launch_file),
                    # No launch_arguments here for remapping, as SetRemap handles it globally
                ),
            ]
        ),
    ])

