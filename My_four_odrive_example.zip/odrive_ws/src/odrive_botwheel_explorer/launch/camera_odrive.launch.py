#!/usr/bin/env python3
import os

from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, IncludeLaunchDescription, RegisterEventHandler
from launch.conditions import IfCondition
from launch.event_handlers import OnProcessExit
from launch.substitutions import Command, FindExecutable, PathJoinSubstitution, LaunchConfiguration
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch_ros.actions import Node
from ament_index_python.packages import get_package_share_directory

def generate_launch_description():
    # 1) Declare any args you want to forward to both brings-up
    declared_arguments = [
        DeclareLaunchArgument('gui', default_value='true',
                              description='Start RViz2 automatically'),
        DeclareLaunchArgument('use_mock_hardware', default_value='false',
                              description='Use mock hardware for odrive'),
    ]
    gui = LaunchConfiguration('gui')
    use_mock = LaunchConfiguration('use_mock_hardware')

    # 2) Build your robot_description via xacro
    robot_description_content = Command([
        FindExecutable(name='xacro'), ' ',
        PathJoinSubstitution([
            get_package_share_directory('odrive_botwheel_explorer'),
            'urdf', 'diffbot.urdf.xacro'
        ]),
        ' use_mock_hardware:=', use_mock
    ])
    robot_description = {'robot_description': robot_description_content}

    # 3) Path to your controller config
    robot_controllers = PathJoinSubstitution([
        get_package_share_directory('odrive_botwheel_explorer'),
        'config', 'diffbot_controllers.yaml'
    ])

    # 4) ODrive ros2_control node + publishers + spawners
    control_node = Node(
        package='controller_manager',
        executable='ros2_control_node',
        parameters=[robot_description, robot_controllers],
        remappings=[
            ('/botwheel_explorer/cmd_vel_unstamped', '/cmd_vel'),
            ('/botwheel_explorer/odom', '/odom'),
        ],
        output='both',
    )
#     
    joint_state_broadcaster_spawner = Node(
        package='controller_manager',
        executable='spawner',
        arguments=['joint_state_broadcaster', '--controller-manager', '/controller_manager'],
    )
    robot_controller_spawner = Node(
        package='controller_manager',
        executable='spawner',
        arguments=['botwheel_explorer', '--controller-manager', '/controller_manager'],
    )
    # delay robot_controller until joint_state_broadcaster is ready
    delay_controller = RegisterEventHandler(
        OnProcessExit(
            target_action=joint_state_broadcaster_spawner,
            on_exit=[robot_controller_spawner],
        )
    )

    # robot_state_publisher
    robot_state_pub = Node(
        package='robot_state_publisher',
        executable='robot_state_publisher',
        parameters=[robot_description],
        output='both',
    )
#    {'use_sim_time': True}

    # optional RViz
    rviz_config = PathJoinSubstitution([
        get_package_share_directory('odrive_ros2_control'),
        'diffbot/rviz', 'diffbot.rviz'
    ])
    rviz_node = Node(
        package='rviz2', executable='rviz2',
        arguments=['-d', rviz_config],
        condition=IfCondition(gui),
    )

    # 5) Include the DepthAI/RTAB-Map launcher
    depthai_launch = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(
            os.path.join(
                get_package_share_directory('odrive_botwheel_explorer'),
                'launch', 'rtabmap.launch.py'
            )
        ),
        # pass along any args that rtabmap.launch.py expects, e.g.:
        launch_arguments={
            'rviz': 'true',
            # if you need to remap its frame_id into your prefix:
            # 'frame_id': LaunchConfiguration('prefix') + 'oak-d-base-frame',
        }.items()
    )

    return LaunchDescription(declared_arguments + [
        control_node,
        joint_state_broadcaster_spawner,
        delay_controller,
        robot_state_pub,
        rviz_node,
        depthai_launch,
    ])

