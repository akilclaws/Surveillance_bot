import rclpy
from rclpy.node import Node
from geometry_msgs.msg import PoseStamped
from nav2_msgs.action import NavigateToPose
from rclpy.action import ActionClient
from std_srvs.srv import Trigger
import yaml
import os

class GoHomeNode(Node):
    def __init__(self):
        super().__init__('go_home_node')
        self.nav_client = ActionClient(self, NavigateToPose, 'navigate_to_pose')
        self.srv = self.create_service(Trigger, 'go_home', self.go_home_callback)

        # Load waypoints
        file_path = os.path.join(os.path.dirname(__file__), 'waypoints.yaml')
        with open(file_path, 'r') as f:
            self.waypoints = yaml.safe_load(f)

        self.get_logger().info("Service /go_home ready. Waypoints loaded.")

    def go_home_callback(self, request, response):
        waypoint = self.waypoints.get('home')
        if not waypoint:
            response.success = False
            response.message = "No 'home' waypoint found."
            return response

        self.nav_client.cancel_all_goals()

        goal_msg = NavigateToPose.Goal()
        goal_msg.pose.header.frame_id = "map"
        goal_msg.pose.header.stamp = self.get_clock().now().to_msg()

        pos = waypoint['position']
        ori = waypoint['orientation']
        goal_msg.pose.pose.position.x = pos['x']
        goal_msg.pose.pose.position.y = pos['y']
        goal_msg.pose.pose.position.z = pos['z']
        goal_msg.pose.pose.orientation.x = ori['x']
        goal_msg.pose.pose.orientation.y = ori['y']
        goal_msg.pose.pose.orientation.z = ori['z']
        goal_msg.pose.pose.orientation.w = ori['w']

        self.nav_client.wait_for_server()
        self.nav_client.send_goal_async(goal_msg)

        response.success = True
        response.message = "Going home."
        return response

def main(args=None):
    rclpy.init(args=args)
    node = GoHomeNode()
    rclpy.spin(node)
    rclpy.shutdown()

